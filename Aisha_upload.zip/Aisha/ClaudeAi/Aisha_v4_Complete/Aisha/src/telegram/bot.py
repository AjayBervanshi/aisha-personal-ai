"""
bot.py
======
Aisha's Telegram Bot — Full implementation.
Features: text chat, voice messages, commands, inline buttons, mood tracking.

Run: python src/telegram/bot.py
"""

import os
import sys
import asyncio
import logging
import tempfile
from datetime import datetime
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

import telebot
from telebot import types
from supabase import create_client
from dotenv import load_dotenv

from src.core.aisha_brain import AishaBrain

load_dotenv()

# ─── Configuration ─────────────────────────────────────────────────────────────

BOT_TOKEN      = os.getenv("TELEGRAM_BOT_TOKEN")
AUTHORIZED_ID  = int(os.getenv("AJAY_TELEGRAM_ID", "0"))  # Only Ajay can use this bot!
SUPABASE_URL   = os.getenv("SUPABASE_URL")
SUPABASE_KEY   = os.getenv("SUPABASE_SERVICE_KEY")

# ─── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("aisha.log")
    ]
)
log = logging.getLogger("Aisha")

# ─── Init ──────────────────────────────────────────────────────────────────────

bot   = telebot.TeleBot(BOT_TOKEN)
aisha = AishaBrain()
db    = create_client(SUPABASE_URL, SUPABASE_KEY)


# ─── Security: Only Ajay can use Aisha ────────────────────────────────────────

def is_ajay(message) -> bool:
    """Only allow Ajay (by Telegram user ID) to access Aisha."""
    if AUTHORIZED_ID == 0:
        return True  # Not configured — allow all (dev mode)
    return message.from_user.id == AUTHORIZED_ID


def unauthorized_response(message):
    bot.reply_to(message, "🔒 Aisha is a private assistant. She belongs to Ajay only 💜")


# ─── Keyboards ─────────────────────────────────────────────────────────────────

def main_keyboard():
    """Main quick-action keyboard."""
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    keyboard.add(
        types.KeyboardButton("💜 Hey Aisha!"),
        types.KeyboardButton("💰 Finance"),
        types.KeyboardButton("📅 My Schedule"),
        types.KeyboardButton("💪 Motivate Me"),
        types.KeyboardButton("📓 Journal"),
        types.KeyboardButton("🎯 My Goals"),
        types.KeyboardButton("📊 Mood Check"),
        types.KeyboardButton("⚙️ Settings"),
    )
    return keyboard

def mood_keyboard():
    """Mood selection keyboard."""
    keyboard = types.InlineKeyboardMarkup(row_width=4)
    moods = [
        ("😄 Amazing", "mood_amazing_9"),
        ("🙂 Good", "mood_good_7"),
        ("😐 Okay", "mood_okay_5"),
        ("😔 Not Good", "mood_notgood_3"),
        ("😢 Bad", "mood_bad_2"),
        ("😤 Angry", "mood_angry_3"),
        ("😰 Anxious", "mood_anxious_3"),
        ("😴 Tired", "mood_tired_4"),
    ]
    buttons = [types.InlineKeyboardButton(label, callback_data=data) 
               for label, data in moods]
    keyboard.add(*buttons)
    return keyboard


# ─── Commands ─────────────────────────────────────────────────────────────────

@bot.message_handler(commands=["start"])
def cmd_start(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    hour = datetime.now().hour
    greeting = "Good morning" if 5 <= hour < 12 else \
               "Good afternoon" if 12 <= hour < 17 else \
               "Good evening" if 17 <= hour < 22 else "Hey"
    
    welcome = (
        f"💜 *{greeting}, Ajay!*\n\n"
        "I'm Aisha — your personal companion. I'm here for everything:\n"
        "💬 Talk to me, vent to me, ask me anything\n"
        "💰 Track expenses, plan finances\n"
        "📅 Manage your schedule and reminders\n"
        "💪 Get motivated, journal your thoughts\n"
        "🎯 Work on your goals together\n\n"
        "_I remember everything you share with me. Always here, Aju 💜_"
    )
    bot.send_message(
        message.chat.id,
        welcome,
        parse_mode="Markdown",
        reply_markup=main_keyboard()
    )

@bot.message_handler(commands=["help"])
def cmd_help(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    help_text = (
        "🌟 *Aisha — Command Guide*\n\n"
        "You can just *talk to me normally* — no commands needed!\n"
        "But here are some handy ones:\n\n"
        "📋 *Quick Commands:*\n"
        "/start — Greet Aisha\n"
        "/mood — Log how you're feeling\n"
        "/today — See today's tasks + summary\n"
        "/addtask — Add a task or reminder\n"
        "/expense — Log an expense quickly\n"
        "/journal — Write a journal entry\n"
        "/goals — See your active goals\n"
        "/memory — See what Aisha remembers\n"
        "/reset — Start a fresh conversation\n\n"
        "💬 *Or just say:*\n"
        "• 'I spent ₹500 on food'\n"
        "• 'Remind me to call mama at 6pm'\n"
        "• 'I'm feeling stressed'\n"
        "• 'Motivate me'\n"
        "• 'What are my goals?'\n\n"
        "🎙️ You can also send *voice messages!*"
    )
    bot.send_message(message.chat.id, help_text, parse_mode="Markdown")

@bot.message_handler(commands=["mood"])
def cmd_mood(message):
    if not is_ajay(message): return unauthorized_response(message)
    bot.send_message(
        message.chat.id,
        "💜 *How are you feeling right now, Ajay?*",
        parse_mode="Markdown",
        reply_markup=mood_keyboard()
    )

@bot.message_handler(commands=["today"])
def cmd_today(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    today = datetime.now().date().isoformat()
    tasks = db.table("aisha_schedule") \
              .select("title, priority, status") \
              .eq("due_date", today) \
              .execute().data or []
    
    spending = db.table("aisha_finance") \
                 .select("amount") \
                 .eq("type", "expense") \
                 .eq("date", today) \
                 .execute().data or []
    
    total_spend = sum(r["amount"] for r in spending)
    
    pending = [t for t in tasks if t["status"] == "pending"]
    done    = [t for t in tasks if t["status"] == "done"]
    
    task_lines = ""
    for t in pending:
        emoji = "🔴" if t["priority"] == "urgent" else \
                "🟠" if t["priority"] == "high" else \
                "🟡" if t["priority"] == "medium" else "🟢"
        task_lines += f"{emoji} {t['title']}\n"
    
    today_msg = (
        f"📅 *Today — {datetime.now().strftime('%A, %d %B')}*\n\n"
        f"✅ Completed: {len(done)} tasks\n"
        f"⏳ Pending: {len(pending)} tasks\n"
        f"💰 Spent today: ₹{total_spend:,.0f}\n\n"
    )
    if task_lines:
        today_msg += f"*Pending tasks:*\n{task_lines}"
    else:
        today_msg += "_No pending tasks — enjoy your day! 🌟_"
    
    bot.send_message(message.chat.id, today_msg, parse_mode="Markdown")

@bot.message_handler(commands=["expense"])
def cmd_expense(message):
    if not is_ajay(message): return unauthorized_response(message)
    bot.send_message(
        message.chat.id,
        "💰 Tell me what you spent!\n\nJust say it naturally, like:\n"
        "_'₹200 on chai and snacks'_\n_'500 for auto-rickshaw'_\n"
        "_'1500 grocery shopping'_",
        parse_mode="Markdown"
    )

@bot.message_handler(commands=["goals"])
def cmd_goals(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    goals = db.table("aisha_goals") \
              .select("title, category, progress, timeframe") \
              .eq("status", "active") \
              .order("progress", desc=False) \
              .execute().data or []
    
    if not goals:
        bot.send_message(message.chat.id, 
            "🎯 You don't have any active goals yet!\nTell me your goals and I'll track them for you 💜")
        return
    
    goals_text = "🎯 *Your Active Goals*\n\n"
    for g in goals:
        bar = "█" * (g["progress"] // 10) + "░" * (10 - g["progress"] // 10)
        goals_text += f"*{g['title']}*\n"
        goals_text += f"  {bar} {g['progress']}% | {g['timeframe']}\n\n"
    
    bot.send_message(message.chat.id, goals_text, parse_mode="Markdown")

@bot.message_handler(commands=["memory"])
def cmd_memory(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    memories = db.table("aisha_memory") \
                 .select("category, title, importance") \
                 .eq("is_active", True) \
                 .order("importance", desc=True) \
                 .limit(10) \
                 .execute().data or []
    
    mem_text = "🧠 *What Aisha Remembers About You*\n\n"
    for m in memories:
        stars = "⭐" * m["importance"]
        mem_text += f"{stars} [{m['category'].upper()}] {m['title']}\n"
    
    if not memories:
        mem_text += "_Nothing stored yet — talk to me more! 💜_"
    
    bot.send_message(message.chat.id, mem_text, parse_mode="Markdown")

@bot.message_handler(commands=["reset"])
def cmd_reset(message):
    if not is_ajay(message): return unauthorized_response(message)
    aisha.reset_session()
    bot.send_message(
        message.chat.id, 
        "🔄 Fresh start! I'm ready, Ajay 💜",
        reply_markup=main_keyboard()
    )

@bot.message_handler(commands=["journal"])
def cmd_journal(message):
    if not is_ajay(message): return unauthorized_response(message)
    bot.send_message(
        message.chat.id,
        "📓 *Time to journal, Ajay...*\n\n"
        "Just write freely — how was your day? What's on your mind?\n"
        "I'm listening 💜",
        parse_mode="Markdown"
    )


# ─── Callback Handlers (Inline Buttons) ───────────────────────────────────────

@bot.callback_query_handler(func=lambda c: c.data.startswith("mood_"))
def handle_mood_callback(call):
    parts     = call.data.split("_")
    mood_name = parts[1]
    score     = int(parts[2])
    
    aisha.memory.update_mood(mood_name, score)
    
    mood_responses = {
        "amazing": "That's AMAZING Ajay!! 🎉 What made today so great? Tell me everything!",
        "good":    "Love that 🙂 What's been good today?",
        "okay":    "Okay is okay, Aju 💜 Anything on your mind?",
        "notgood": "Hey, I'm here 💜 Want to talk about what's going on?",
        "bad":     "Ajay... come talk to me. What happened? I'm listening 💜",
        "angry":   "Arre kya hua yaar? 😤 Tell me everything — let it out.",
        "anxious": "Breathe, Aju. I've got you. What's making you anxious? 💜",
        "tired":   "Rest is important too 💜 Have you been taking care of yourself?"
    }
    
    response = mood_responses.get(mood_name, "Got it, Ajay. I'm here 💜")
    
    bot.answer_callback_query(call.id)
    bot.send_message(call.message.chat.id, response)


# ─── Quick Action Buttons ──────────────────────────────────────────────────────

QUICK_ACTIONS = {
    "💜 Hey Aisha!":   "Hey Aisha! I just wanted to say hi",
    "💰 Finance":       "Help me with my finances today",
    "📅 My Schedule":   "What does my schedule look like today?",
    "💪 Motivate Me":   "Aisha please motivate me right now!",
    "📓 Journal":       "I want to write a journal entry",
    "🎯 My Goals":      "/goals",
    "📊 Mood Check":    "/mood",
    "⚙️ Settings":     "Show me settings and what I can customize",
}

@bot.message_handler(func=lambda m: m.text in QUICK_ACTIONS)
def handle_quick_action(message):
    if not is_ajay(message): return unauthorized_response(message)
    action = QUICK_ACTIONS[message.text]
    if action.startswith("/"):
        # Route to command
        message.text = action
        bot.process_new_messages([message])
    else:
        handle_text(message, override_text=action)


# ─── Voice Message Handler ─────────────────────────────────────────────────────

@bot.message_handler(content_types=["voice"])
def handle_voice(message):
    if not is_ajay(message): return unauthorized_response(message)
    
    # Download voice file
    file_info = bot.get_file(message.voice.file_id)
    downloaded = bot.download_file(file_info.file_path)
    
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as f:
        f.write(downloaded)
        voice_path = f.name
    
    # Try transcription with Gemini
    try:
        import google.generativeai as genai
        audio_file = genai.upload_file(voice_path)
        transcript_model = genai.GenerativeModel("gemini-1.5-flash")
        result = transcript_model.generate_content([
            "Transcribe this voice message exactly as spoken. "
            "It may be in English, Hindi, or Marathi.",
            audio_file
        ])
        transcribed_text = result.text.strip()
        
        bot.send_message(message.chat.id, 
            f"🎙️ _Heard: \"{transcribed_text}\"_", 
            parse_mode="Markdown")
        
        # Process as normal message
        response = aisha.think(transcribed_text, platform="telegram")
        bot.send_message(message.chat.id, response)
        
    except Exception as e:
        log.error(f"Voice transcription failed: {e}")
        bot.send_message(message.chat.id, 
            "Arre Ajay, I couldn't catch that voice message 😅 "
            "Try typing it out? Technical issue on my end!")
    finally:
        os.unlink(voice_path)


# ─── Main Text Handler ─────────────────────────────────────────────────────────

@bot.message_handler(func=lambda message: True)
def handle_text(message, override_text=None):
    if not is_ajay(message): return unauthorized_response(message)
    
    user_text = override_text or message.text
    if not user_text or not user_text.strip():
        return
    
    # Show typing indicator
    bot.send_chat_action(message.chat.id, "typing")
    
    try:
        log.info(f"[{message.from_user.first_name}] {user_text[:80]}")
        response = aisha.think(user_text, platform="telegram")
        
        # Split long responses (Telegram limit: 4096 chars)
        if len(response) > 4000:
            chunks = [response[i:i+4000] for i in range(0, len(response), 4000)]
            for chunk in chunks:
                bot.send_message(message.chat.id, chunk)
        else:
            bot.send_message(message.chat.id, response)
            
    except Exception as e:
        log.error(f"Error processing message: {e}")
        bot.send_message(
            message.chat.id,
            "Arre yaar, kuch gadbad ho gayi 😅 Try again in a moment, Ajay!"
        )


# ─── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    log.info("💜 Aisha Telegram Bot starting...")
    log.info(f"Authorized user ID: {AUTHORIZED_ID or 'ALL (dev mode)'}")
    
    bot.set_my_commands([
        telebot.types.BotCommand("/start",   "Start / Greet Aisha"),
        telebot.types.BotCommand("/today",   "Today's summary"),
        telebot.types.BotCommand("/mood",    "Log your mood"),
        telebot.types.BotCommand("/expense", "Log an expense"),
        telebot.types.BotCommand("/goals",   "See your goals"),
        telebot.types.BotCommand("/journal", "Write a journal entry"),
        telebot.types.BotCommand("/memory",  "What Aisha remembers"),
        telebot.types.BotCommand("/help",    "Help & commands"),
        telebot.types.BotCommand("/reset",   "Reset conversation"),
    ])
    
    print("✅ Aisha is live on Telegram! 💜")
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
